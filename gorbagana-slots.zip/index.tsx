/*
  Gorbagana Trash Rush - Slot Game Prototype

  Instructions for setup:
  1. This file contains the complete React application.
  2. Ensure you have React and ReactDOM installed in your project.
  3. This project uses Tailwind CSS for styling. Make sure it's included, for example via a CDN link in your index.html.
  4. Image assets are embedded as base64 SVGs in `assets.tsx`.
*/
import React, { useState, useMemo, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { IMAGES } from './assets.tsx';

// --- Game Configuration ---

const SYMBOLS = {
  gorbagana: { id: 'gorbagana', payout: 50, weight: 1, img: IMAGES.gorbagana },
  trash: { id: 'trash', payout: 25, weight: 2, img: IMAGES.trashcan },
  takeout: { id: 'takeout', payout: 20, weight: 3, img: IMAGES.takeout },
  fish: { id: 'fish', payout: 15, weight: 4, img: IMAGES.fish },
  rat: { id: 'rat', payout: 10, weight: 5, img: IMAGES.rat },
  banana: { id: 'banana', payout: 5, weight: 6, img: IMAGES.banana },
};

type SymbolId = keyof typeof SYMBOLS;

const REEL_ROWS = 3;
const REEL_COLS = 3;
const SPIN_COST = 1;
const INITIAL_BALANCE = 100;
const SPIN_ANIMATION_DURATION = 1000; // ms
const SPIN_ANIMATION_INTERVAL = 100; // ms

// --- Helper function to create the initial grid state ---
const createInitialGrid = (): SymbolId[][] => {
  const symbolKeys = Object.keys(SYMBOLS) as SymbolId[];
  const getRandomSymbolId = () => symbolKeys[Math.floor(Math.random() * symbolKeys.length)];
  return Array(REEL_ROWS).fill(null).map(() => 
    Array(REEL_COLS).fill(null).map(getRandomSymbolId)
  );
};

// --- SlotGame Component ---

const SlotGame = () => {
  const [balance, setBalance] = useState(INITIAL_BALANCE);
  const [lastWin, setLastWin] = useState<number>(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [grid, setGrid] = useState<SymbolId[][]>(createInitialGrid);
  const [winningLines, setWinningLines] = useState<number[]>([]);

  // Memoize the weighted pool to avoid recalculating on every render
  const weightedSymbolPool = useMemo<SymbolId[]>(() => {
    const pool: SymbolId[] = [];
    for (const symbolId of Object.keys(SYMBOLS) as SymbolId[]) {
      const symbol = SYMBOLS[symbolId];
      for (let i = 0; i < symbol.weight; i++) {
        pool.push(symbolId);
      }
    }
    return pool;
  }, []);

  const getRandomWeightedSymbol = (): SymbolId => {
    const randomIndex = Math.floor(Math.random() * weightedSymbolPool.length);
    return weightedSymbolPool[randomIndex];
  };

  const calculateWinnings = (currentGrid: SymbolId[][]) => {
    let totalWin = 0;
    const lines: number[] = [];
    
    for (let i = 0; i < REEL_ROWS; i++) {
      const row = currentGrid[i];
      if (row[0] === row[1] && row[1] === row[2]) {
        const symbol = SYMBOLS[row[0]];
        totalWin += symbol.payout;
        lines.push(i);
      }
    }
    return { totalWin, lines };
  };

  const handleSpin = () => {
    if (isSpinning || balance < SPIN_COST) {
      if (!isSpinning && balance < SPIN_COST) {
        alert("You don't have enough credits to spin!");
      }
      return;
    }

    setIsSpinning(true);
    setLastWin(0);
    setWinningLines([]);

    const animationInterval = setInterval(() => {
      setGrid(prevGrid =>
        prevGrid.map(row => row.map(() => getRandomWeightedSymbol()))
      );
    }, SPIN_ANIMATION_INTERVAL);

    setTimeout(() => {
      clearInterval(animationInterval);

      const finalGrid: SymbolId[][] = Array(REEL_ROWS).fill(null).map(() =>
        Array(REEL_COLS).fill(null).map(() => getRandomWeightedSymbol())
      );
      
      setGrid(finalGrid);
      
      const { totalWin, lines } = calculateWinnings(finalGrid);
      const newBalance = balance - SPIN_COST + totalWin;
      
      setBalance(newBalance);

      if (totalWin > 0) {
        setLastWin(totalWin);
        setWinningLines(lines);
      }

      setIsSpinning(false);
      
      if (newBalance < SPIN_COST) {
         setTimeout(() => alert("Game Over! You're out of credits."), 200);
      }
    }, SPIN_ANIMATION_DURATION);
  };
  
  // Preload images
  useEffect(() => {
    Object.values(SYMBOLS).forEach(symbol => {
      const img = new Image();
      img.src = symbol.img;
    });
  }, []);

  const titleShadowStyle = (color: string) => ({
    textShadow: `0 0 15px ${color}, 0 2px 2px rgba(0,0,0,0.7)`
  });

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#0a021d] text-white p-2 antialiased" style={{ fontFamily: "'Exo 2', sans-serif" }}>
      <div className="relative w-full max-w-[420px] min-h-[800px] bg-[#000] rounded-[3rem] p-4 flex flex-col justify-between shadow-[0_0_15px_#0ff,0_0_25px_#f0f,0_0_35px_#f70,inset_0_0_10px_rgba(10,2,29,1)] border border-fuchsia-500/50">

        {/* Header */}
        <header>
          <div className="flex justify-between items-center text-yellow-400 font-bold px-2">
            <div className="text-center w-28 py-1 border-2 border-fuchsia-600/50" style={{ clipPath: 'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)' }}>GRAND</div>
            <div className="w-20 h-6 border-2 border-fuchsia-600/50" style={{ clipPath: 'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)' }}></div>
            <div className="text-center w-28 py-1 border-2 border-fuchsia-600/50" style={{ clipPath: 'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)' }}>MINOR</div>
          </div>
          <div className="text-center my-4 select-none">
            <h1 className="text-5xl md:text-6xl font-black uppercase text-transparent bg-clip-text bg-gradient-to-b from-cyan-300 to-blue-600 drop-shadow-lg" style={titleShadowStyle('rgba(0,255,255,0.5)')}>
                Gorbagana
            </h1>
            <h2 className="text-5xl md:text-6xl font-black uppercase text-transparent bg-clip-text bg-gradient-to-b from-orange-400 to-amber-600 -mt-2 drop-shadow-lg" style={titleShadowStyle('rgba(255,165,0,0.5)')}>
                Trash Rush
            </h2>
          </div>
        </header>

        {/* Reels */}
        <main className="relative w-full aspect-square p-2 border-2 border-fuchsia-500/80 rounded-2xl shadow-[0_0_25px_rgba(192,38,211,0.5),inset_0_0_15px_rgba(192,38,211,0.3)] bg-black/30">
          <div className="grid grid-cols-3 grid-rows-3 gap-2 h-full">
            {grid.flat().map((symbolId, index) => (
              <div 
                key={index}
                className={`bg-slate-900/50 rounded-lg flex items-center justify-center overflow-hidden transition-all duration-300
                  ${winningLines.includes(Math.floor(index / REEL_COLS)) ? 'shadow-[0_0_15px_5px_#fde047] scale-105 bg-yellow-400/20' : ''}`}
              >
                <img 
                  src={SYMBOLS[symbolId].img} 
                  alt={symbolId} 
                  className="w-full h-full object-contain p-2 transition-transform duration-100 ease-in-out"
                  style={{ transform: isSpinning ? 'scale(0.8) rotate(15deg)' : 'scale(1) rotate(0deg)' }}
                />
              </div>
            ))}
          </div>
        </main>
        
        {/* Controls */}
        <footer className="w-full flex items-center justify-between text-yellow-400 mt-4 px-1">
            <div className="text-center border-2 border-fuchsia-500/80 rounded-lg p-2 w-24 h-14 flex items-center justify-center cursor-pointer hover:bg-fuchsia-500/20 transition-colors">
                <span className="uppercase font-bold text-sm tracking-wider">Settings</span>
            </div>

            <div className="flex-grow flex flex-col items-center">
                 <div className="relative text-center py-1 px-10 text-yellow-400">
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 text-5xl font-thin transform -scale-x-100" style={{fontFamily:'serif'}}>)</span>
                    <span className="absolute right-0 top-1/2 -translate-y-1/2 text-5xl font-thin" style={{fontFamily:'serif'}}>)</span>
                    <span className="font-black text-3xl tracking-widest">WIN</span>
                </div>
                <div className="text-white text-2xl font-bold h-8">{lastWin > 0 ? lastWin.toFixed(2) : ''}</div>
            </div>

            <div className="flex items-center gap-3">
                 <div className="text-center">
                    <p className="text-white font-bold text-lg">{SPIN_COST.toFixed(2)}</p>
                    <p className="text-gray-400 text-[10px] uppercase cursor-pointer">Auto</p>
                </div>
                <button
                    onClick={handleSpin}
                    disabled={isSpinning || balance < SPIN_COST}
                    aria-label={isSpinning ? 'Spinning...' : 'Spin the reels'}
                    className="w-20 h-20 rounded-full bg-gradient-to-b from-blue-500 to-indigo-800 text-white font-black text-2xl uppercase shadow-[0_5px_15px_rgba(0,0,0,0.5),inset_0_-4px_10px_rgba(0,0,0,0.8),inset_0_2px_2px_rgba(255,255,255,0.2)] border-2 border-blue-300/50 transition-all duration-150 disabled:from-gray-600 disabled:to-gray-800 disabled:text-gray-400 disabled:cursor-not-allowed disabled:shadow-none active:translate-y-1 active:shadow-[0_2px_5px_rgba(0,0,0,0.5),inset_0_-2px_5px_rgba(0,0,0,0.8)]"
                >
                    {isSpinning ? '' : 'Spin'}
                </button>
            </div>
        </footer>
      </div>
    </div>
  );
};

// --- React App Entry Point ---

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <SlotGame />
    </React.StrictMode>
  );
}